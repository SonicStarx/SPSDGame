<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Tiles5v2" tilewidth="16" tileheight="16" spacing="2" margin="2" tilecount="1479" columns="17">
 <image source="../../../../Hack Submission/Space Pirates Shoedown/core/assets/tiledassets/img/1/tilesheet.png" width="320" height="1568"/>
</tileset>
