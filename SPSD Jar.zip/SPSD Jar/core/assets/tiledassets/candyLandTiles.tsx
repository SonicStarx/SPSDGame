<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="candyLandTiles" tilewidth="32" tileheight="32" tilecount="504" columns="28">
 <image source="CandyLand/CandyLand1.jpg" width="914" height="587"/>
</tileset>
