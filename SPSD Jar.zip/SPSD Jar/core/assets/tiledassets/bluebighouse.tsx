<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="bluebighouse" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="391" columns="23">
 <image source="img/1/bluebighouse.png" width="800" height="600"/>
 <tile id="0">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
