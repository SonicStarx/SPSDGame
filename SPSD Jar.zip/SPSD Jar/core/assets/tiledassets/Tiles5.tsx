<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Tiles5" tilewidth="32" tileheight="32" tilecount="490" columns="10">
 <grid orientation="orthogonal" width="10" height="10"/>
 <image source="img/1/tilesheet.png" width="320" height="1568"/>
 <tile id="8">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="invisible" value=""/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="74">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="77">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="85">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="94">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="95">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="101">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="111">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="basicEnemy" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="140">
  <properties>
   <property name="basicEnemy" value="true"/>
  </properties>
 </tile>
 <tile id="365">
  <properties>
   <property name="newWorld" value="true"/>
  </properties>
 </tile>
 <tile id="366">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="367">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="368">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="375">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="376">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="377">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="378">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="379">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="385">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="386">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="387">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="388">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="389">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="396">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="397">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="398">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="406">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="407">
  <properties>
   <property name="enter" value="true"/>
  </properties>
 </tile>
 <tile id="408">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="468">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="469">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="473">
  <properties>
   <property name="oldWorld" value="true"/>
  </properties>
 </tile>
 <tile id="478">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="479">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
