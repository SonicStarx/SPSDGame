<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="ChocolateFountain" tilewidth="64" tileheight="76" tilecount="1" columns="1">
 <image source="ChocolateFountain.png" width="64" height="76"/>
 <tile id="0">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
