<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="watertiles2" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="391" columns="23">
 <image source="../../../../Hack Submission/Space Pirates Shoedown/core/assets/tiledassets/img/1/watertiles2.png" width="800" height="600"/>
</tileset>
