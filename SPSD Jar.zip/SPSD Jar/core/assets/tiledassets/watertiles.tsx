<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="watertiles" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="391" columns="23">
 <image source="img/1/watertiles.png" width="800" height="600"/>
 <tile id="27">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
