<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="redhouse" tilewidth="32" tileheight="32" tilecount="450" columns="25">
 <image source="img/1/redhouse.png" width="800" height="600"/>
 <tile id="0">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="77">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="101">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="102">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
